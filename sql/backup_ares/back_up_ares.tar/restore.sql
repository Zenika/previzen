--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.6 (Debian 11.6-1.pgdg90+1)
-- Dumped by pg_dump version 12.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE db;
--
-- Name: db; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE db WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE db OWNER TO root;

\connect db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

--
-- Name: absence_jaz; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.absence_jaz (
    id_absence_jaz integer NOT NULL,
    id_consultant integer NOT NULL,
    comment text NOT NULL,
    date integer NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    duration real NOT NULL
);


ALTER TABLE public.absence_jaz OWNER TO root;

--
-- Name: absence_jaz_id_absence_jaz_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.absence_jaz_id_absence_jaz_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.absence_jaz_id_absence_jaz_seq OWNER TO root;

--
-- Name: absence_jaz_id_absence_jaz_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.absence_jaz_id_absence_jaz_seq OWNED BY public.absence_jaz.id_absence_jaz;


--
-- Name: absence_off; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.absence_off (
    id_absence_off integer NOT NULL,
    id_consultant integer NOT NULL,
    comment text NOT NULL,
    date integer NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    duration real NOT NULL
);


ALTER TABLE public.absence_off OWNER TO root;

--
-- Name: absence_off_id_absence_off_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.absence_off_id_absence_off_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.absence_off_id_absence_off_seq OWNER TO root;

--
-- Name: absence_off_id_absence_off_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.absence_off_id_absence_off_seq OWNED BY public.absence_off.id_absence_off;


--
-- Name: billable_days; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.billable_days (
    id_billable_day integer NOT NULL,
    id_consultant integer NOT NULL,
    nb_billable_days integer NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL
);


ALTER TABLE public.billable_days OWNER TO root;

--
-- Name: billable_days_id_billable_day_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.billable_days_id_billable_day_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.billable_days_id_billable_day_seq OWNER TO root;

--
-- Name: billable_days_id_billable_day_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.billable_days_id_billable_day_seq OWNED BY public.billable_days.id_billable_day;


--
-- Name: consultants; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.consultants (
    id_consultant integer NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    starts_after_month integer NOT NULL,
    starts_after_year integer NOT NULL,
    leaves_after_month integer,
    leaves_after_year integer
);


ALTER TABLE public.consultants OWNER TO root;

--
-- Name: consultants_id_consultant_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.consultants_id_consultant_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.consultants_id_consultant_seq OWNER TO root;

--
-- Name: consultants_id_consultant_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.consultants_id_consultant_seq OWNED BY public.consultants.id_consultant;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.customers (
    id_customer integer NOT NULL,
    customer_name text NOT NULL
);


ALTER TABLE public.customers OWNER TO root;

--
-- Name: customers_id_customer_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.customers_id_customer_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customers_id_customer_seq OWNER TO root;

--
-- Name: customers_id_customer_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.customers_id_customer_seq OWNED BY public.customers.id_customer;


--
-- Name: daily_costs; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.daily_costs (
    id_daily_cost integer NOT NULL,
    id_consultant integer NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    price real NOT NULL
);


ALTER TABLE public.daily_costs OWNER TO root;

--
-- Name: daily_costs_id_daily_cost_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.daily_costs_id_daily_cost_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.daily_costs_id_daily_cost_seq OWNER TO root;

--
-- Name: daily_costs_id_daily_cost_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.daily_costs_id_daily_cost_seq OWNED BY public.daily_costs.id_daily_cost;


--
-- Name: staffing; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.staffing (
    id_staffing integer NOT NULL,
    id_consultant integer NOT NULL,
    id_customer integer NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    duration double precision NOT NULL,
    price integer NOT NULL
);


ALTER TABLE public.staffing OWNER TO root;

--
-- Name: staffing_id_staffing_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.staffing_id_staffing_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.staffing_id_staffing_seq OWNER TO root;

--
-- Name: staffing_id_staffing_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.staffing_id_staffing_seq OWNED BY public.staffing.id_staffing;


--
-- Name: absence_jaz id_absence_jaz; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.absence_jaz ALTER COLUMN id_absence_jaz SET DEFAULT nextval('public.absence_jaz_id_absence_jaz_seq'::regclass);


--
-- Name: absence_off id_absence_off; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.absence_off ALTER COLUMN id_absence_off SET DEFAULT nextval('public.absence_off_id_absence_off_seq'::regclass);


--
-- Name: billable_days id_billable_day; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.billable_days ALTER COLUMN id_billable_day SET DEFAULT nextval('public.billable_days_id_billable_day_seq'::regclass);


--
-- Name: consultants id_consultant; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultants ALTER COLUMN id_consultant SET DEFAULT nextval('public.consultants_id_consultant_seq'::regclass);


--
-- Name: customers id_customer; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.customers ALTER COLUMN id_customer SET DEFAULT nextval('public.customers_id_customer_seq'::regclass);


--
-- Name: daily_costs id_daily_cost; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.daily_costs ALTER COLUMN id_daily_cost SET DEFAULT nextval('public.daily_costs_id_daily_cost_seq'::regclass);


--
-- Name: staffing id_staffing; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.staffing ALTER COLUMN id_staffing SET DEFAULT nextval('public.staffing_id_staffing_seq'::regclass);


--
-- Data for Name: absence_jaz; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.absence_jaz (id_absence_jaz, id_consultant, comment, date, month, year, duration) FROM stdin;
\.
COPY public.absence_jaz (id_absence_jaz, id_consultant, comment, date, month, year, duration) FROM '$$PATH$$/2929.dat';

--
-- Data for Name: absence_off; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.absence_off (id_absence_off, id_consultant, comment, date, month, year, duration) FROM stdin;
\.
COPY public.absence_off (id_absence_off, id_consultant, comment, date, month, year, duration) FROM '$$PATH$$/2931.dat';

--
-- Data for Name: billable_days; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.billable_days (id_billable_day, id_consultant, nb_billable_days, month, year) FROM stdin;
\.
COPY public.billable_days (id_billable_day, id_consultant, nb_billable_days, month, year) FROM '$$PATH$$/2933.dat';

--
-- Data for Name: consultants; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.consultants (id_consultant, first_name, last_name, starts_after_month, starts_after_year, leaves_after_month, leaves_after_year) FROM stdin;
\.
COPY public.consultants (id_consultant, first_name, last_name, starts_after_month, starts_after_year, leaves_after_month, leaves_after_year) FROM '$$PATH$$/2935.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.customers (id_customer, customer_name) FROM stdin;
\.
COPY public.customers (id_customer, customer_name) FROM '$$PATH$$/2937.dat';

--
-- Data for Name: daily_costs; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.daily_costs (id_daily_cost, id_consultant, month, year, price) FROM stdin;
\.
COPY public.daily_costs (id_daily_cost, id_consultant, month, year, price) FROM '$$PATH$$/2941.dat';

--
-- Data for Name: staffing; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.staffing (id_staffing, id_consultant, id_customer, month, year, duration, price) FROM stdin;
\.
COPY public.staffing (id_staffing, id_consultant, id_customer, month, year, duration, price) FROM '$$PATH$$/2939.dat';

--
-- Name: absence_jaz_id_absence_jaz_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.absence_jaz_id_absence_jaz_seq', 759, true);


--
-- Name: absence_off_id_absence_off_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.absence_off_id_absence_off_seq', 1615, true);


--
-- Name: billable_days_id_billable_day_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.billable_days_id_billable_day_seq', 740, true);


--
-- Name: consultants_id_consultant_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.consultants_id_consultant_seq', 74, true);


--
-- Name: customers_id_customer_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.customers_id_customer_seq', 53, true);


--
-- Name: daily_costs_id_daily_cost_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.daily_costs_id_daily_cost_seq', 2, true);


--
-- Name: staffing_id_staffing_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.staffing_id_staffing_seq', 1161, true);


--
-- Name: absence_jaz absence_jaz_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.absence_jaz
    ADD CONSTRAINT absence_jaz_pkey PRIMARY KEY (id_absence_jaz);


--
-- Name: absence_off absence_off_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.absence_off
    ADD CONSTRAINT absence_off_pkey PRIMARY KEY (id_absence_off);


--
-- Name: billable_days billable_days_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.billable_days
    ADD CONSTRAINT billable_days_pkey PRIMARY KEY (id_billable_day);


--
-- Name: consultants consultants_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultants
    ADD CONSTRAINT consultants_pkey PRIMARY KEY (id_consultant);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id_customer);


--
-- Name: daily_costs daily_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.daily_costs
    ADD CONSTRAINT daily_costs_pkey PRIMARY KEY (id_daily_cost);


--
-- Name: staffing staffing_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.staffing
    ADD CONSTRAINT staffing_pkey PRIMARY KEY (id_staffing);


--
-- Name: absence_jaz absence_jaz_id_consultant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.absence_jaz
    ADD CONSTRAINT absence_jaz_id_consultant_fkey FOREIGN KEY (id_consultant) REFERENCES public.consultants(id_consultant);


--
-- Name: absence_off absence_off_id_consultant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.absence_off
    ADD CONSTRAINT absence_off_id_consultant_fkey FOREIGN KEY (id_consultant) REFERENCES public.consultants(id_consultant);


--
-- Name: billable_days billable_days_id_consultant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.billable_days
    ADD CONSTRAINT billable_days_id_consultant_fkey FOREIGN KEY (id_consultant) REFERENCES public.consultants(id_consultant);


--
-- Name: daily_costs daily_costs_id_consultant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.daily_costs
    ADD CONSTRAINT daily_costs_id_consultant_fkey FOREIGN KEY (id_consultant) REFERENCES public.consultants(id_consultant);


--
-- Name: staffing staffing_id_consultant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.staffing
    ADD CONSTRAINT staffing_id_consultant_fkey FOREIGN KEY (id_consultant) REFERENCES public.consultants(id_consultant);


--
-- Name: staffing staffing_id_customer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.staffing
    ADD CONSTRAINT staffing_id_customer_fkey FOREIGN KEY (id_customer) REFERENCES public.customers(id_customer);


--
-- PostgreSQL database dump complete
--

